export const USER_API_END_POINT="http://localhost:8000/api/user";
export const JOB_API_END_POINT="http://localhost:8000/api/job";
export const APPLICATION_API_END_POINT="http://localhost:8000/api/application";
export const COMPANY_API_END_POINT="http://localhost:8000/api/company";